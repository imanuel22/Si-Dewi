@extends('Admin.layouts.main')

@section('main')
    <h1>Halaman informasi desa</h1>
    
@endsection