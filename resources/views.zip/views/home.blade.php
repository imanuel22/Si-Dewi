@extends('components.layout')

@section('main')
    Home
@endsection